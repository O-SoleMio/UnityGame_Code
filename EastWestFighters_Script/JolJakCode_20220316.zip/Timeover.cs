﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Timeover : MonoBehaviour
{
    //float size = 0;
    //float tick = 0;
    //GameObject[] Cube;
    //int i;
    //public Color col;
    
    //// Start is called before the first frame update
    //void Start()
    //{
    //    i = 0;
    //    Cube = GameObject.FindGameObjectsWithTag("Cube");
    //}

    //// Update is called once per frame
    //void Update()
    //{
    //    col = Cube[i].GetComponent<Renderer>().material.color;
    //    //tick += Time.deltaTime / 1000.0f;
    //    tick += Time.deltaTime;



    //    //col.r += Time.smoothDeltaTime * 0.1f;
    //    col.b -= Time.smoothDeltaTime * 0.1f;
    //    col.g -= Time.smoothDeltaTime * 0.1f;
    //    Cube[i].GetComponent<Renderer>().material.color = col;

    //    if (tick > 3.0f)
    //    {
           

    //        Cube[i].SetActive(false);
    //        i += 1;
    //            tick = 0.0f;          
    //    }
       
    //====================================================================
        ////if (tick == 1000.0f)
        ////{
        //    size += Time.deltaTime / 100;
        ////tick = 0;
        ////}

        //if (transform.localScale.x > 0 && transform.localScale.y > 0) { 
        //transform.localScale = new Vector3
        //    (transform.localScale.x - size,
        //    transform.localScale.y ,
        //    transform.localScale.z - size);
        //}

    //}
}
